<?php

return [
    'name' => 'Connector',
    'module_version' => "1.4",
    'pid' => 9
];
