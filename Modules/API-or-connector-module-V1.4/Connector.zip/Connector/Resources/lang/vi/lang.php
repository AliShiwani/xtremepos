<?php
return [
	"connector_module"=>"Mô-đun trình kết nối",
	"connector"=>"Trình kết nối",
	"create_client"=>"Tạo ứng dụng khách",
	"client_secret"=>"bí mật ứng dụng khách",
	"clients"=>"khách hàng",
	"documentation"=>"tài liệu",
];