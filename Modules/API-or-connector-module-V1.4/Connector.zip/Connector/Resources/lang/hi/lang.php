<?php
return [
	"connector_module"=>"कनेक्टर मॉड्यूल",
	"connector"=>"कनेक्टर",
	"create_client"=>"क्लाइंट बनाएं",
	"client_secret"=>"क्लाइंट सीक्रेट",
	"clients"=>"ग्राहक",
	"documentation"=>"दस्तावेज़",
];